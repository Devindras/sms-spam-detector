
# ==========================================================
# TRAINING SCRIPT FOR SMS SPAM DETECTOR
# Produces all files needed for Streamlit Web App
# ==========================================================

import pandas as pd
import numpy as np
import re
import joblib
from gensim.models import Word2Vec
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import MultinomialNB

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
    return text

def sentence_vector(tokens, model, size=100):
    words = [model.wv[w] for w in tokens if w in model.wv]
    return np.mean(words, axis=0) if words else np.zeros(size)

df = pd.read_csv("spam.csv", encoding="latin-1")[["v1", "v2"]]
df.columns = ["label", "text"]
df["label"] = df["label"].map({"ham": 0, "spam": 1})
df["clean"] = df["text"].apply(clean_text)

X_train, X_test, y_train, y_test = train_test_split(
    df["clean"], df["label"], test_size=0.2,
    random_state=42, stratify=df["label"]
)

tfidf = TfidfVectorizer(stop_words="english", max_features=5000)
X_train_tfidf = tfidf.fit_transform(X_train)
X_test_tfidf = tfidf.transform(X_test)

train_tokens = [t.split() for t in X_train]
test_tokens = [t.split() for t in X_test]

w2v_model = Word2Vec(sentences=train_tokens, vector_size=100,
                     window=5, min_count=1, workers=4)

X_train_w2v = np.array([sentence_vector(tokens, w2v_model) for tokens in train_tokens])
X_test_w2v = np.array([sentence_vector(tokens, w2v_model) for tokens in test_tokens])

models_tfidf = {
    "NB (TF-IDF)": MultinomialNB(),
    "LR (TF-IDF)": LogisticRegression(max_iter=2000),
    "SVM (TF-IDF)": LinearSVC(),
    "RF (TF-IDF)": RandomForestClassifier(n_estimators=200, max_depth=20)
}

models_w2v = {
    "LR (W2V)": LogisticRegression(max_iter=2000),
    "SVM (W2V)": LinearSVC(),
    "RF (W2V)": RandomForestClassifier(n_estimators=200, max_depth=20)
}

results = {}
model_objects = {}

print("\n========== TRAINING MODELS ==========\n")

for name, model in models_tfidf.items():
    model.fit(X_train_tfidf, y_train)
    acc = model.score(X_test_tfidf, y_test)
    results[name] = acc
    model_objects[name] = model
    print(f"{name} Accuracy: {acc:.4f}")

for name, model in models_w2v.items():
    model.fit(X_train_w2v, y_train)
    acc = model.score(X_test_w2v, y_test)
    results[name] = acc
    model_objects[name] = model
    print(f"{name} Accuracy: {acc:.4f}")

best_model_name = max(results, key=results.get)
best_accuracy = results[best_model_name]
best_model = model_objects[best_model_name]

if "W2V" in best_model_name:
    best_feature_type = "w2v"
else:
    best_feature_type = "tfidf"

print("\n======================================")
print(f"BEST MODEL: {best_model_name} (Acc = {best_accuracy:.4f})")
print(f"FEATURE TYPE: {best_feature_type}")
print("======================================\n")

joblib.dump(best_model, "best_spam_model.pkl")
joblib.dump(tfidf, "tfidf_vectorizer.pkl")
w2v_model.save("word2vec.model")

with open("best_feature_type.txt", "w") as f:
    f.write(best_feature_type)

print("Saved:")
print("  best_spam_model.pkl")
print("  tfidf_vectorizer.pkl")
print("  word2vec.model")
print("  best_feature_type.txt")
