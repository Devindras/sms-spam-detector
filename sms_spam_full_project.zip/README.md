# SMS Spam Detection Web App
This repository contains:
- Streamlit Web App (app.py)
- Training Script (train_spam_classifier.py)
- Requirements file for deployment
Upload to GitHub and deploy via Streamlit Cloud.
