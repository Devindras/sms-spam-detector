
import streamlit as st
import joblib
import numpy as np
import re
from gensim.models import Word2Vec
from lime.lime_text import LimeTextExplainer

def clean_text(text):
    text = text.lower()
    text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
    return text

def sentence_vector(tokens, model, size=100):
    words = [model.wv[w] for w in tokens if w in model.wv]
    return np.mean(words, axis=0) if words else np.zeros(size)

feature_type = open("best_feature_type.txt").read().strip()
model = joblib.load("best_spam_model.pkl")

if feature_type == "tfidf":
    vectorizer = joblib.load("tfidf_vectorizer.pkl")
else:
    w2v_model = Word2Vec.load("word2vec.model")

st.set_page_config(page_title="SMS Spam Detector", page_icon="📱", layout="centered")

st.title("📱 SMS Spam Detection Web App")
st.write("This model was trained using TF-IDF + Word2Vec embeddings. Enter a message below.")

user_text = st.text_area("✉️ Enter SMS message:", height=120)

explainer = LimeTextExplainer(class_names=["Ham", "Spam"])

def predict_proba_for_lime(texts):
    cleaned = [clean_text(t) for t in texts]

    if feature_type == "tfidf":
        X = vectorizer.transform(cleaned)
    else:
        X = np.array([sentence_vector(c.split(), w2v_model) for c in cleaned])

    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X)
    elif hasattr(model, "decision_function"):
        raw = model.decision_function(X)
        scaled = (raw - raw.min()) / (raw.max() - raw.min() + 1e-9)
        probs = np.vstack([1 - scaled, scaled]).T

    return probs

if st.button("🔍 Predict Spam / Ham"):
    if not user_text.strip():
        st.warning("Please type a message.")
    else:
        cleaned = clean_text(user_text)
        tokens = cleaned.split()

        if feature_type == "tfidf":
            X = vectorizer.transform([cleaned])
        else:
            X = np.array([sentence_vector(tokens, w2v_model)])

        pred = model.predict(X)[0]
        label = "🚨 SPAM" if pred == 1 else "✔️ HAM (Not Spam)"

        st.subheader("Prediction:")
        st.markdown(f"## {label}")

        st.subheader("🔍 Explanation (LIME)")
        explanation = explainer.explain_instance(
            user_text, predict_proba_for_lime, num_features=10
        )
        st.components.v1.html(explanation.as_html(), height=500, scrolling=True)

st.write("---")
st.write("Built with ❤️ using Streamlit + TF-IDF + Word2Vec + LIME.")
